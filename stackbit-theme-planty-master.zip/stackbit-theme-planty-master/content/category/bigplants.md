---
title: Big plants
layout: category
order: 1
seo:
  title: Big plants
  description: This is the store page
  extra:
    - name: og:type
      value: website
      keyName: property
    - name: og:title
      value: Big plants
      keyName: property
    - name: og:description
      value: This is the store page
      keyName: property
    - name: og:image
      value: images/plant1-lg.jpg
      keyName: property
      relativeUrl: true
    - name: twitter:card
      value: summary_large_image
    - name: twitter:title
      value: Big plants
    - name: twitter:description
      value: This is the store page
    - name: twitter:image
      value: images/plant1-lg.jpg
      relativeUrl: true
---
