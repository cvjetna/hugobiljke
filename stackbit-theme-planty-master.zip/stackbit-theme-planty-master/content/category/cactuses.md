---
title: Cactuses
layout: category
order: 2
seo:
  title: Cactuses
  description: This is the store page
  extra:
    - name: og:type
      value: website
      keyName: property
    - name: og:title
      value: Cactuses
      keyName: property
    - name: og:description
      value: This is the store page
      keyName: property
    - name: og:image
      value: images/plant2-lg.jpg
      keyName: property
      relativeUrl: true
    - name: twitter:card
      value: summary_large_image
    - name: twitter:title
      value: Cactuses
    - name: twitter:description
      value: This is the store page
    - name: twitter:image
      value: images/plant2-lg.jpg
      relativeUrl: true
---
