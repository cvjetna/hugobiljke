---
layout: product
id: '7'
price: '18.90'
title: Sed consectetur
description: Fusce sed tortor id diam rhoncus accumsan.
default_thumbnail_image: images/plant7.jpg
default_original_image: images/plant7-lg.jpg
order: 7
category: content/category/bigplants.md
seo:
  title: Sed consectetur
  description: Fusce sed tortor id diam rhoncus accumsan
  extra:
    - name: og:type
      value: website
      keyName: property
    - name: og:title
      value: Sed consectetur
      keyName: property
    - name: og:description
      value: Fusce sed tortor id diam rhoncus accumsan
      keyName: property
    - name: og:image
      value: images/plant7-lg.jpg
      keyName: property
      relativeUrl: true
    - name: twitter:card
      value: summary_large_image
    - name: twitter:title
      value: Sed consectetur
    - name: twitter:description
      value: Fusce sed tortor id diam rhoncus accumsan
    - name: twitter:image
      value: images/plant7-lg.jpg
      relativeUrl: true
---

# Sed consectetur

Sed consectetur eleifend neque. Morbi fringilla velit neque, quis aliquet diam rutrum eget. Praesent dui leo, iaculis non auctor sed, accumsan at felis. Suspendisse eu pretium justo. Curabitur et velit quis justo elementum iaculis. Fusce sed tortor id diam rhoncus accumsan. In cursus sagittis eros non congue.