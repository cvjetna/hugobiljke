---
layout: product
id: '8'
price: '50.00'
title: Fusce sed
description: In cursus sagittis eros non congue.
default_thumbnail_image: images/plant8.jpg
default_original_image: images/plant8-lg.jpg
order: 8
category: content/category/summer.md
seo:
  title: Fusce sed
  description: In cursus sagittis eros non congue
  extra:
    - name: og:type
      value: website
      keyName: property
    - name: og:title
      value: Fusce sed
      keyName: property
    - name: og:description
      value: In cursus sagittis eros non congue
      keyName: property
    - name: og:image
      value: images/plant8-lg.jpg
      keyName: property
      relativeUrl: true
    - name: twitter:card
      value: summary_large_image
    - name: twitter:title
      value: Fusce sed
    - name: twitter:description
      value: In cursus sagittis eros non congue
    - name: twitter:image
      value: images/plant8-lg.jpg
      relativeUrl: true
---

# Fusce sed

Sed consectetur eleifend neque. Morbi fringilla velit neque, quis aliquet diam rutrum eget. Praesent dui leo, iaculis non auctor sed, accumsan at felis. Suspendisse eu pretium justo. Curabitur et velit quis justo elementum iaculis. Fusce sed tortor id diam rhoncus accumsan. In cursus sagittis eros non congue.