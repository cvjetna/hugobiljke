---
layout: product
id: '9'
price: '400.00'
title: Fusce sagittis
description: Nulla diam diam, maximus gravida efficitur eu, ultricies quis orci.
default_thumbnail_image: images/plant9.jpg
default_original_image: images/plant9-lg.jpg
featured: true
order: 9
category: content/category/cactuses.md
seo:
  title: Fusce sagittis
  description: Nulla diam diam, maximus gravida efficitur eu, ultricies quis orci
  extra:
    - name: og:type
      value: website
      keyName: property
    - name: og:title
      value: Fusce sagittis
      keyName: property
    - name: og:description
      value: Nulla diam diam, maximus gravida efficitur eu, ultricies quis orci
      keyName: property
    - name: og:image
      value: images/plant9-lg.jpg
      keyName: property
      relativeUrl: true
    - name: twitter:card
      value: summary_large_image
    - name: twitter:title
      value: Fusce sagittis
    - name: twitter:description
      value: Nulla diam diam, maximus gravida efficitur eu, ultricies quis orci
    - name: twitter:image
      value: images/plant9-lg.jpg
      relativeUrl: true
---

# Fusce sagittis

Vestibulum blandit sem mattis metus blandit pharetra at at ipsum. Vestibulum luctus quis turpis ac sollicitudin. Etiam ultricies pharetra velit. Nulla diam diam, maximus gravida efficitur eu, ultricies quis orci. Donec congue pharetra massa, ut venenatis nibh volutpat vel. Quisque eu sapien arcu. Nunc feugiat dictum tincidunt. Etiam sodales tellus tempus auctor vehicula. Praesent eget sapien dignissim, vehicula quam id, vehicula libero. Fusce sagittis gravida nulla ac bibendum. Duis lacinia egestas fringilla. Fusce quis metus semper, molestie massa finibus, laoreet magna. Aliquam gravida ipsum id nisl efficitur aliquam.