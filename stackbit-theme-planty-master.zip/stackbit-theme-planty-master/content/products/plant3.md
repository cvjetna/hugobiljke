---
layout: product
id: '3'
price: '150.00'
title: Curabitur eu tempor
description: Nulla non pretium metus, vitae finibus lectus.
default_thumbnail_image: images/plant3.jpg
default_original_image: images/plant3-lg.jpg
featured: true
order: 3
category: content/category/cactuses.md
seo:
  title: Curabitur eu tempor
  description: Nulla non pretium metus, vitae finibus lectus
  extra:
    - name: og:type
      value: website
      keyName: property
    - name: og:title
      value: Curabitur eu tempor
      keyName: property
    - name: og:description
      value: Nulla non pretium metus, vitae finibus lectus
      keyName: property
    - name: og:image
      value: images/plant3-lg.jpg
      keyName: property
      relativeUrl: true
    - name: twitter:card
      value: summary_large_image
    - name: twitter:title
      value: Curabitur eu tempor
    - name: twitter:description
      value: Nulla non pretium metus, vitae finibus lectus
    - name: twitter:image
      value: images/plant3-lg.jpg
      relativeUrl: true
---

# Curabitur eu tempor

Aliquam quis laoreet lectus. Proin non mattis nulla, quis posuere mi. Mauris venenatis, magna at pellentesque commodo, lectus risus vehicula elit, nec dignissim nisl sapien id leo. Nulla non pretium metus, vitae finibus lectus. Aliquam in posuere risus. Curabitur ultrices ornare magna porttitor commodo. Curabitur eu tempor orci, sed pretium quam. Vestibulum condimentum, arcu nec pulvinar fringilla, lorem odio varius arcu, in porta tellus eros sed neque. Suspendisse efficitur eget erat sit amet efficitur. Proin maximus nibh eu sapien consequat, non porttitor risus consequat. Donec maximus odio sed nibh convallis luctus.