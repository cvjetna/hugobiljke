window.removeHamburgerMenuHandlers();
