window.addHamburgerMenuHandlers();
