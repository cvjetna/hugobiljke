<div hidden id="snipcart" data-api-key="__SNIPCART_API_KEY__"></div>
